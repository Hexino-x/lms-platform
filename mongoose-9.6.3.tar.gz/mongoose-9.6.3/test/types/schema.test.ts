import {
  DefaultSchemaOptions,
  HydratedArraySubdocument,
  HydratedSingleSubdocument,
  Schema,
  Document,
  HydratedDocument,
  IndexDefinition,
  IndexOptions,
  InferRawDocType,
  InferSchemaType,
  InsertManyOptions,
  JSONSerialized,
  ObtainDocumentType,
  ObtainSchemaGeneric,
  ResolveSchemaOptions,
  SchemaDefinition,
  SchemaOptions,
  SchemaTypeOptions,
  Model,
  SchemaType,
  Types,
  Query,
  model,
  ValidateOpts,
  CallbackWithoutResultAndOptionalError,
  InferRawDocTypeFromSchema,
  InferHydratedDocTypeFromSchema,
  FlatRecord,
  InferHydratedDocType
} from 'mongoose';
import { BSON, Binary, UUID } from 'mongodb';
import { ObtainDocumentPathType, ResolvePathType } from '../../types/inferschematype';
import { ExpectAssignable, ExpectType } from './util/assertions';

enum Genre {
  Action,
  Adventure,
  Comedy
}

interface Actor {
  name: string,
  age: number
}
const actorSchema =
  new Schema<Actor & Document, Model<Actor & Document>, Actor>({ name: { type: String }, age: { type: Number } });

interface Movie {
  title?: string,
  featuredIn?: string,
  rating?: number,
  genre?: string,
  actionIntensity?: number,
  status?: string,
  actors: Actor[]
}

const movieSchema = new Schema<Document & Movie, Model<Document & Movie>>({
  title: {
    type: String,
    index: 'text'
  },
  featuredIn: {
    type: String,
    enum: ['Favorites', null],
    default: null
  },
  rating: {
    type: Number,
    required: [true, 'Required'],
    min: [0, 'MinValue'],
    max: [5, 'MaxValue']
  },
  genre: {
    type: String,
    enum: Genre,
    required: true
  },
  actionIntensity: {
    type: Number,
    required: [
      function(this: { genre: Genre }) {
        return this.genre === Genre.Action;
      },
      'Action intensity required for action genre'
    ]
  },
  status: {
    type: String,
    enum: {
      values: ['Announced', 'Released'],
      message: 'Invalid value for `status`'
    }
  },
  actors: {
    type: [actorSchema],
    default: undefined
  }
});

movieSchema.index({ status: 1, 'actors.name': 1 });
movieSchema.index({ title: 'text' }, {
  weights: { title: 10 }
});
movieSchema.index({ rating: -1 });
movieSchema.index({ title: 1 }, { unique: true });
movieSchema.index({ title: 1 }, { unique: [true, 'Title must be unique'] as const });
movieSchema.index({ tile: 'ascending' });
movieSchema.index({ tile: 'asc' });
movieSchema.index({ tile: 'descending' });
movieSchema.index({ tile: 'desc' });
movieSchema.index({ tile: 'hashed' });
movieSchema.index({ tile: 'geoHaystack' });

// @ts-expect-error  Type '2' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: 2 });
// @ts-expect-error  Type '-2' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: -2 });
// @ts-expect-error  Type '""' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: '' });
// @ts-expect-error  Type '"invalid"' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: 'invalid' });
// @ts-expect-error  Type 'Date' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: new Date() });
// @ts-expect-error  Type 'true' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: true });
// @ts-expect-error  Type 'false' is not assignable to type 'IndexDirection'.
movieSchema.index({ tile: false });

// Using `SchemaDefinition`
interface IProfile {
  age: number;
}
const ProfileSchemaDef: SchemaDefinition<IProfile> = { age: Number };
export const ProfileSchema = new Schema<IProfile, Model<IProfile>>(ProfileSchemaDef);

interface IUser {
  email: string;
  profile: IProfile;
}

const ProfileSchemaDef2: SchemaDefinition<IProfile> = {
  age: Schema.Types.Number
};

const ProfileSchema2: Schema<IProfile, Model<IProfile>> = new Schema<IProfile, Model<IProfile>>(ProfileSchemaDef2);

const UserSchemaDef: SchemaDefinition<IUser> = {
  email: String,
  profile: ProfileSchema2
};

async function gh9857() {
  interface User {
    name: number;
    active: boolean;
    points: number;
  }

  type UserDocument = Document<User>;
  type UserSchemaDefinition = SchemaDefinition<User>;
  type UserModel = Model<UserDocument>;

  const u: UserSchemaDefinition = {
    // @ts-expect-error  Type '{ type: StringConstructor; }' is not assignable to type 'SchemaDefinitionProperty<number, any, any> | undefined'.
    name: { type: String },
    active: { type: Boolean },
    points: Number
  };
}

function gh10261() {
  interface ValuesEntity {
    values: string[];
  }

  const type: ReadonlyArray<typeof String> = [String];
  const colorEntitySchemaDefinition: SchemaDefinition<ValuesEntity> = {
    values: {
      type: type,
      required: true
    }
  };
}

function gh10287() {
  interface SubSchema {
    testProp: string;
  }

  const subSchema = new Schema<Document & SubSchema, Model<Document & SubSchema>, SubSchema>({
    testProp: Schema.Types.String
  });

  interface MainSchema {
    subProp: SubSchema
  }

  const mainSchema1 = new Schema<Document & MainSchema, Model<Document & MainSchema>, MainSchema>({
    subProp: subSchema
  });

  const mainSchema2 = new Schema<Document & MainSchema, Model<Document & MainSchema>, MainSchema>({
    subProp: {
      type: subSchema
    }
  });
}

function gh10370() {
  const movieSchema = new Schema<Document & Movie, Model<Document & Movie>, Movie>({
    actors: {
      type: [actorSchema]
    }
  });
}

function gh10409() {
  interface Something {
    field: Date;
  }
  const someSchema = new Schema<Something, Model<Something>, Something>({
    field: { type: Date }
  });
}

function gh10605() {
  interface ITest {
    arrayField?: string[];
    object: {
      value: number
    };
  }
  const schema = new Schema<ITest>({
    arrayField: [String],
    object: {
      type: {
        value: {
          type: Number
        }
      }
    }
  });
}

function gh10605_2() {
  interface ITestSchema {
    someObject: Array<{ id: string }>
  }

  const testSchema = new Schema<ITestSchema>({
    someObject: { type: [{ id: String }] }
  });
}

function gh10731() {
  interface IProduct {
    keywords: string[];
  }

  const productSchema = new Schema<IProduct>({
    keywords: {
      type: [
        {
          type: String,
          trim: true,
          lowercase: true,
          required: true
        }
      ],
      required: true
    }
  });
}

function gh10789() {
  interface IAddress {
    city: string;
    state: string;
    country: string;
  }

  interface IUser {
    name: string;
    addresses: IAddress[];
  }

  const addressSchema = new Schema<IAddress>({
    city: {
      type: String,
      required: true
    },
    state: {
      type: String,
      required: true
    },
    country: {
      type: String,
      required: true
    }
  });

  const userSchema = new Schema<IUser>({
    name: {
      type: String,
      required: true
    },
    addresses: {
      type: [
        {
          type: addressSchema,
          required: true
        }
      ],
      required: true
    }
  });
}

function gh11439() {
  type Book = {
    collection: string
  };

  const bookSchema = new Schema<Book>({
    collection: String
  }, {
    suppressReservedKeysWarning: true
  });
}

function gh11448() {
  interface IUser {
    name: string;
    age: number;
  }

  const userSchema = new Schema<IUser>({ name: String, age: Number });

  userSchema.pick<Pick<IUser, 'age'>>(['age']);
}

function gh11435(): void {
  interface User {
    ids: Types.Array<Types.ObjectId>;
  }

  const schema = new Schema<User>({
    ids: {
      type: [{ type: Schema.Types.ObjectId, ref: 'Something' }],
      default: []
    }
  });
}

// timeSeries
new Schema({}, { expires: '5 seconds' });
new Schema({}, {
  // @ts-expect-error  Type 'string' is not assignable to type 'number'.
  expireAfterSeconds: '5 seconds'
});
new Schema({}, { expireAfterSeconds: 5 });

function gh10900(): void {
  type TMenuStatus = Record<string, 'EXPANDED' | 'COLLAPSED'>[];

  interface IUserProp {
    menuStatus: TMenuStatus;
  }

  const patientSchema = new Schema<IUserProp>({
    menuStatus: { type: Schema.Types.Mixed, default: {} }
  });
}

export function autoTypedSchema() {
  // Test auto schema type obtaining with all possible path types.

  class Int8 extends SchemaType {
    constructor(key: string, options: Record<string, any>) {
      super(key, options, 'Int8');
    }
    cast(val: unknown) {
      let _val = Number(val);
      if (isNaN(_val)) {
        throw new Error('Int8: ' + val + ' is not a number');
      }
      _val = Math.round(_val);
      if (_val < -0x80 || _val > 0x7F) {
        throw new Error('Int8: ' + val +
          ' is outside of the range of valid 8-bit ints');
      }
      return _val;
    }
  }

  type TestSchemaType = {
    string1?: string | null;
    string2?: string | null;
    string3?: string | null;
    string4?: string | null;
    string5: string;
    number1?: number | null;
    number2?: number | null;
    number3?: number | null;
    number4?: number | null;
    number5: number;
    date1?: Date | null;
    date2?: Date | null;
    date3?: Date | null;
    date4?: Date | null;
    date5: Date;
    buffer1?: Buffer | null;
    buffer2?: Buffer | null;
    buffer3?: Buffer | null;
    buffer4?: Buffer | null;
    boolean1?: boolean | null;
    boolean2?: boolean | null;
    boolean3?: boolean | null;
    boolean4?: boolean | null;
    boolean5: boolean;
    mixed1?: any | null;
    mixed2?: any | null;
    mixed3?: any | null;
    objectId1?: Types.ObjectId | null;
    objectId2?: Types.ObjectId | null;
    objectId3?: Types.ObjectId | null;
    customSchema?: Int8 | null;
    map1?: Map<string, string> | null;
    map2?: Map<string, number> | null;
    array1: string[];
    array2: any[];
    array3: any[];
    array4: any[];
    array5: any[];
    array6: string[];
    array7?: string[] | null;
    array8?: string[] | null;
    decimal1?: Types.Decimal128 | null;
    decimal2?: Types.Decimal128 | null;
    decimal3?: Types.Decimal128 | null;
  };

  const TestSchema = new Schema({
    string1: String,
    string2: 'String',
    string3: 'string',
    string4: Schema.Types.String,
    string5: { type: String, default: 'ABCD' },
    number1: Number,
    number2: 'Number',
    number3: 'number',
    number4: Schema.Types.Number,
    number5: { type: Number, default: 10 },
    date1: Date,
    date2: 'Date',
    date3: 'date',
    date4: Schema.Types.Date,
    date5: { type: Date, default: new Date() },
    buffer1: Buffer,
    buffer2: 'Buffer',
    buffer3: 'buffer',
    buffer4: Schema.Types.Buffer,
    boolean1: Boolean,
    boolean2: 'Boolean',
    boolean3: 'boolean',
    boolean4: Schema.Types.Boolean,
    boolean5: { type: Boolean, default: true },
    mixed1: Object,
    mixed2: {},
    mixed3: Schema.Types.Mixed,
    objectId1: Schema.Types.ObjectId,
    objectId2: 'ObjectId',
    objectId3: 'ObjectID',
    customSchema: Int8,
    map1: { type: Map, of: String },
    map2: { type: Map, of: Number },
    array1: [String],
    array2: Array,
    array3: [Schema.Types.Mixed],
    array4: [{}],
    array5: [],
    array6: { type: [String] },
    array7: { type: [String], default: undefined },
    array8: { type: [String], default: () => undefined },
    decimal1: Schema.Types.Decimal128,
    decimal2: 'Decimal128',
    decimal3: 'decimal128'
  });

  type InferredTestSchemaType = InferSchemaType<typeof TestSchema>;

  ExpectType<TestSchemaType>({} as InferredTestSchemaType);

  const SchemaWithCustomTypeKey = new Schema({
    name: {
      customTypeKey: String,
      required: true
    }
  }, {
    typeKey: 'customTypeKey'
  });

  ExpectType<string>({} as InferSchemaType<typeof SchemaWithCustomTypeKey>['name']);

  const AutoTypedSchema = new Schema({
    userName: {
      type: String,
      required: [true, 'userName is required']
    },
    description: String,
    nested: new Schema({
      age: {
        type: Number,
        required: true
      },
      hobby: {
        type: String,
        required: false
      }
    }),
    favoritDrink: {
      type: String,
      enum: ['Coffee', 'Tea']
    },
    favoritColorMode: {
      type: String,
      enum: {
        values: ['dark', 'light'],
        message: '{VALUE} is not supported'
      },
      required: true
    },
    friendID: {
      type: Schema.Types.ObjectId
    },
    nestedArray: {
      type: [
        new Schema({
          date: { type: Date, required: true },
          messages: Number
        })
      ]
    }
  }, {
    statics: {
      staticFn() {
        ExpectAssignable<Model<InferSchemaType<typeof AutoTypedSchema>>>()(this);
        return 'Returned from staticFn' as const;
      }
    },
    methods: {
      instanceFn() {
        ExpectAssignable<HydratedDocument<InferSchemaType<typeof AutoTypedSchema>>>()(this);
        return 'Returned from DocumentInstanceFn' as const;
      }
    },
    query: {
      byUserName(userName) {
        ExpectAssignable<Query<unknown, InferSchemaType<typeof AutoTypedSchema>>>()(this);
        return this.where({ userName });
      }
    }
  });

  return AutoTypedSchema;
}

export type AutoTypedSchemaType = {
  schema: {
    userName: string;
    description?: string | null;
    nested?: {
      age: number;
      hobby?: string | null
    } | null,
    favoritDrink?: 'Tea' | 'Coffee' | null,
    favoritColorMode: 'dark' | 'light'
    friendID?: Types.ObjectId | null;
    nestedArray: Types.DocumentArray<{
      date: Date;
      messages?: number | null;
    }>
  }
  , statics: {
    staticFn: () => 'Returned from staticFn'
  },
  methods: {
    instanceFn: () => 'Returned from DocumentInstanceFn'
  }
};

// discriminator
const eventSchema = new Schema<{ message: string }>({ message: String }, { discriminatorKey: 'kind' });
const batchSchema = new Schema<{ name: string }>({ name: String }, { discriminatorKey: 'kind' });
batchSchema.discriminator('event', eventSchema);

// discriminator statics
const eventSchema2 = new Schema({ message: String }, { discriminatorKey: 'kind', statics: { static1: function() {
  return 0;
} } });
const batchSchema2 = new Schema({ name: String }, { discriminatorKey: 'kind', statics: { static2: function() {
  return 1;
} } });
batchSchema2.discriminator('event', eventSchema2);


function encryptionType() {
  const keyId = new BSON.UUID();
  new Schema({ name: { type: String, encrypt: { keyId } } },
    // @ts-expect-error  Argument of type '{ encryptionType: "newFakeEncryptionType"; }' is not assignable
    { encryptionType: 'newFakeEncryptionType' }
  );
  new Schema({ name: { type: String, encrypt: { keyId } } },
    // @ts-expect-error  Argument of type '{ encryptionType: number; }' is not assignable
    { encryptionType: 1 }
  );

  ExpectType<Schema>(new Schema({ name: { type: String, encrypt: { keyId } } }, { encryptionType: 'queryableEncryption' }));
  ExpectType<Schema>(new Schema({ name: { type: String, encrypt: { keyId } } }, { encryptionType: 'csfle' }));
}

function gh11828() {
  interface IUser {
    name: string;
    age: number;
    bornAt: Date;
    isActive: boolean;
  }

  const t: SchemaTypeOptions<boolean> = {
    type: Boolean,
    default() {
      return this.name === 'Hafez';
    }
  };

  new Schema<IUser>({
    name: { type: String, default: () => 'Hafez' },
    age: { type: Number, default: () => 27 },
    bornAt: { type: Date, default: () => new Date() },
    isActive: {
      type: Boolean,
      default(): boolean {
        return this.name === 'Hafez';
      }
    }
  });
}

function gh11997() {
  interface IUser {
    name: string;
  }

  const userSchema = new Schema<IUser>({
    name: { type: String, default: () => 'Hafez' }
  });
  userSchema.index({ name: 1 }, { weights: { name: 1 } });
}

function gh12003() {
  const baseSchemaOptions = {
    versionKey: false
  } as const;

  const BaseSchema = new Schema({
    name: String
  }, baseSchemaOptions);

  type BaseSchemaType = InferSchemaType<typeof BaseSchema>;

  type TSchemaOptions = ResolveSchemaOptions<ObtainSchemaGeneric<typeof BaseSchema, 'TSchemaOptions'>>;
  ExpectType<'type'>({} as TSchemaOptions['typeKey']);
  ExpectType<false>({} as TSchemaOptions['versionKey']);

  ExpectType<{ name?: string | null }>({} as BaseSchemaType);
}

function gh11987() {
  interface IUser {
    name: string;
    email: string;
    organization: Types.ObjectId;
  }

  const userSchema = new Schema<IUser>({
    name: { type: String, required: true },
    email: { type: String, required: true },
    organization: { type: Schema.Types.ObjectId, ref: 'Organization' }
  });

  ExpectType<SchemaType<string>>(userSchema.path<'name'>('name'));
  // @ts-expect-error  Type '"foo"' does not satisfy the constraint 'keyof IUser'.
  userSchema.path<'foo'>('name');
  ExpectType<SchemaTypeOptions<string>>(userSchema.path<'name'>('name').OptionsConstructor);
}

function gh12030() {
  const Schema1 = new Schema({
    users: [
      {
        username: { type: String }
      }
    ]
  });

  type A = ResolvePathType<[
    {
      username: { type: String }
    }
  ]>;
  ExpectType<Types.DocumentArray<{ username?: string | null }>>({} as A);

  type B = ObtainDocumentType<{
    users: [
      {
        username: { type: String }
      }
    ]
  }>;
  type BExpectedType = {
    users: Types.DocumentArray<{
      username?: string | null
    }>;
  };
  ExpectType<BExpectedType>({} as B);

  type Schema1ExpectedType = {
    users: Types.DocumentArray<{
      username?: string | null
    }>;
  };
  ExpectType<Schema1ExpectedType>({} as InferSchemaType<typeof Schema1>);

  const Schema2 = new Schema({
    createdAt: { type: Date, default: Date.now }
  });

  ExpectType<{ createdAt: Date }>({} as InferSchemaType<typeof Schema2>);

  const Schema3 = new Schema({
    users: [
      new Schema({
        username: { type: String },
        credit: { type: Number, default: 0 }
      })
    ]
  });

  type Schema3ExpectedType = {
    users: Types.DocumentArray<{
      credit: number;
      username?: string | null;
    }>;
  };
  ExpectType<Schema3ExpectedType>({} as InferSchemaType<typeof Schema3>);


  const Schema4 = new Schema({
    data: { type: { role: String }, default: {} }
  });

  ExpectType<{ data: { role?: string | null } }>({} as InferSchemaType<typeof Schema4>);

  const Schema5 = new Schema({
    data: { type: { role: Object }, default: {} }
  });

  ExpectType<{ data: { role?: any } }>({} as InferSchemaType<typeof Schema5>);

  const Schema6 = new Schema({
    track: {
      backupCount: {
        type: Number,
        default: 0
      },
      count: {
        type: Number,
        default: 0
      }
    }
  });

  type ExpectedType = {
    track?: {
      backupCount: number;
      count: number;
    } | null;
  };
  ExpectType<ExpectedType>({} as InferSchemaType<typeof Schema6>);

}

function pluginOptions() {
  interface SomePluginOptions {
    option1?: string;
    option2: number;
  }

  function pluginFunction(schema: Schema<any>, options: SomePluginOptions) {
    return; // empty function, to satisfy lint option
  }

  const schema = new Schema({});
  ExpectType<Schema<any>>(schema.plugin(pluginFunction)); // test that chaining would be possible

  // test basic inference
  // @ts-expect-error  Property 'option2' is missing in type '{}' but required in type 'SomePluginOptions'.
  schema.plugin(pluginFunction, {});
  schema.plugin(pluginFunction, { option2: 0 });
  schema.plugin(pluginFunction, { option1: 'string', option2: 1 });
  // @ts-expect-error  Property 'option2' is missing in type '{ option1: string; }'
  schema.plugin(pluginFunction, { option1: 'string' });
  // @ts-expect-error  Type 'string' is not assignable to type 'number'.
  schema.plugin(pluginFunction, { option2: 'string' });
  // @ts-expect-error  Type 'number' is not assignable to type 'string'.
  schema.plugin(pluginFunction, { option1: 0 });

  // test plugins without options defined
  function pluginFunction2(schema: Schema<any>) {
    return; // empty function, to satisfy lint option
  }
  schema.plugin(pluginFunction2);
  // @ts-expect-error  Argument of type '{}' is not assignable to parameter of type 'undefined'.
  schema.plugin(pluginFunction2, {});

  // test overwriting options
  schema.plugin<any, SomePluginOptions>(pluginFunction2, { option2: 0 });
  // @ts-expect-error  Property 'option2' is missing in type '{}' but required in type 'SomePluginOptions'.
  schema.plugin<any, SomePluginOptions>(pluginFunction2, {});
}

function gh12205() {
  const campaignSchema = new Schema(
    {
      client: {
        type: new Types.ObjectId(),
        required: true
      }
    }
  );

  const Campaign = model('Campaign', campaignSchema);
  const doc = new Campaign();
  ExpectType<Types.ObjectId>(doc.client);

  type ICampaign = InferSchemaType<typeof campaignSchema>;
  ExpectType<{ client: Types.ObjectId }>({} as ICampaign);

  type A = ObtainDocumentType<{ client: { type: Schema.Types.ObjectId, required: true } }>;
  ExpectType<{ client: Types.ObjectId }>({} as A);

  type Foo = ObtainDocumentPathType<{ type: Schema.Types.ObjectId, required: true }, 'type'>;
  ExpectType<Types.ObjectId>({} as Foo);

  type Bar = ResolvePathType<Schema.Types.ObjectId, { required: true }>;
  ExpectType<Types.ObjectId>({} as Bar);

  /* type Baz = Schema.Types.ObjectId extends typeof Schema.Types.ObjectId ? string : number;
  ExpectType<string>({} as Baz); */
}


function gh12450() {
  const ObjectIdSchema = new Schema({
    user: { type: Schema.Types.ObjectId }
  });

  ExpectType<{ user?: Types.ObjectId | null; }>({} as InferSchemaType<typeof ObjectIdSchema>);

  const Schema2 = new Schema({
    createdAt: { type: Date, required: true },
    decimalValue: { type: Schema.Types.Decimal128, required: true }
  });

  ExpectType<{ createdAt: Date, decimalValue: Types.Decimal128 }>({} as InferSchemaType<typeof Schema2>);

  const Schema3 = new Schema({
    createdAt: { type: Date, required: true },
    decimalValue: { type: Schema.Types.Decimal128 }
  });

  ExpectType<{ createdAt: Date, decimalValue?: Types.Decimal128 | null }>({} as InferSchemaType<typeof Schema3>);

  const Schema4 = new Schema({
    createdAt: { type: Date },
    decimalValue: { type: Schema.Types.Decimal128 }
  });

  ExpectType<{ createdAt?: Date | null, decimalValue?: Types.Decimal128 | null }>({} as InferSchemaType<typeof Schema4>);
}

function gh12242() {
  const dbExample = new Schema(
    {
      active: { type: Number, enum: [0, 1] as const, required: true }
    }
  );

  type Example = InferSchemaType<typeof dbExample>;
  ExpectType<0 | 1>({} as Example['active']);
}

function testInferTimestamps() {
  const schema = new Schema({
    name: String
  }, { timestamps: true });

  type WithTimestamps = InferSchemaType<typeof schema>;
  // For some reason, ExpectType<{ createdAt: Date, updatedAt: Date, name?: string }> throws
  // an error "Parameter type { createdAt: Date; updatedAt: Date; name?: string | undefined; }
  // is not identical to argument type { createdAt: NativeDate; updatedAt: NativeDate; } &
  // { name?: string | undefined; }"
  ExpectType<{ createdAt: Date, updatedAt: Date } & { name?: string | null }>({} as WithTimestamps);

  const schema2 = new Schema({
    name: String
  }, {
    timestamps: true,
    methods: { myName(): string | undefined | null {
      return this.name;
    } }
  });

  type WithTimestamps2 = InferSchemaType<typeof schema2>;
  ExpectType<{ createdAt: Date; updatedAt: Date } & { name?: string | null }>({} as WithTimestamps2);

  const TestModel = model('Test', schema2);
  const doc = new TestModel({ name: 'test' });
  ExpectType<string | undefined | null>(doc.name);

  ExpectType<string | undefined | null>(doc.myName());
}

function gh12431() {
  const testSchema = new Schema({
    testDate: { type: Date },
    testDecimal: { type: Schema.Types.Decimal128 }
  });

  type Example = InferSchemaType<typeof testSchema>;
  ExpectType<{ testDate?: Date | null, testDecimal?: Types.Decimal128 | null }>({} as Example);
}

async function gh12593() {
  const testSchema = new Schema({ x: { type: Schema.Types.UUID } });

  type Example = InferSchemaType<typeof testSchema>;
  ExpectType<{ x?: UUID | null }>({} as Example);

  const Test = model('Test', testSchema);

  const doc = await Test.findOne({ x: '4709e6d9-61fd-435e-b594-d748eb196d8f' }).orFail();
  ExpectType<UUID | undefined | null>(doc.x);

  const doc2 = new Test({ x: '4709e6d9-61fd-435e-b594-d748eb196d8f' });
  ExpectType<UUID | undefined | null>(doc2.x);

  const doc3 = await Test.findOne({}).orFail().lean();
  ExpectType<UUID | undefined | null>(doc3.x);

  const arrSchema = new Schema({ arr: [{ type: Schema.Types.UUID }] });

  type ExampleArr = InferSchemaType<typeof arrSchema>;
  ExpectType<{ arr: UUID[] }>({} as ExampleArr);
}

function gh12562() {
  const emailRegExp = /@/;
  const userSchema = new Schema(
    {
      email: {
        type: String,
        trim: true,
        validate: {
          validator: (value: string) => emailRegExp.test(value),
          message: 'Email is not valid'
        },
        index: { // uncomment the index object and for me trim was throwing an error
          partialFilterExpression: {
            email: {
              $exists: true,
              $ne: null
            }
          }
        },
        select: false
      }
    }
  );
}

function gh12590() {
  const UserSchema = new Schema({
    _password: String
  });

  type User = InferSchemaType<typeof UserSchema>;

  const path = UserSchema.path('hashed_password');
  ExpectAssignable<SchemaType<any, HydratedDocument<User>>>()(path);

  UserSchema.path('hashed_password').validate(function(v) {
    ExpectAssignable<HydratedDocument<User>>()(this);
    if (this._password && this._password.length < 8) {
      this.invalidate('password', 'Password must be at least 8 characters.');
    }
  });

}

function gh12611() {
  const reusableFields = {
    description: { type: String, required: true },
    skills: { type: [Schema.Types.ObjectId], ref: 'Skill', default: [] }
  } as const;

  const firstSchema = new Schema({
    ...reusableFields,
    anotherField: String
  });

  type Props = InferSchemaType<typeof firstSchema>;
  type ExpectedPropsType = {
    description: string;
    skills: Types.ObjectId[];
    anotherField?: string | null;
  };
  ExpectType<ExpectedPropsType>({} as Props);
}

function gh12782() {
  const schemaObj = { test: { type: String, required: true } };
  const schema = new Schema(schemaObj);
  type Props = InferSchemaType<typeof schema>;
  ExpectType<{ test: string }>({} as Props);
}

function gh12816() {
  const schema = new Schema({}, { overwriteModels: true });
}

function gh12869() {
  const dbExampleConst = new Schema(
    {
      active: { type: String, enum: ['foo', 'bar'] as const, required: true }
    }
  );

  type ExampleConst = InferSchemaType<typeof dbExampleConst>;
  ExpectType<'foo' | 'bar'>({} as ExampleConst['active']);

  const dbExample = new Schema(
    {
      active: { type: String, enum: ['foo', 'bar'], required: true }
    }
  );

  type Example = InferSchemaType<typeof dbExample>;
  ExpectType<'foo' | 'bar'>({} as Example['active']);
}


function stringEnumInfer() {
  enum StringEnum {
    Foo = 'foo',
    Bar = 'bar'
  }

  const stringEnumSchema = new Schema(
    {
      active: { type: String, enum: StringEnum }
    }
  );

  type StringEnumExample = InferSchemaType<typeof stringEnumSchema>;
  ExpectType<StringEnum | null | undefined>({} as StringEnumExample['active']);

  const stringEnumSchemaRequired = new Schema(
    {
      active: { type: String, enum: StringEnum, required: true }
    }
  );

  type StringEnumRequiredExample = InferSchemaType<typeof stringEnumSchemaRequired>;
  ExpectAssignable<StringEnum>()({} as StringEnumRequiredExample['active']);
}
function stringEnumArrayInfer() {
  enum StringEnum {
    Foo = 'foo',
    Bar = 'bar'
  }

  const schemaDefinition = {
    active: { type: [String], enum: StringEnum, required: false }
  } as const;
  const stringEnumSchema = new Schema(
    {
      active: { type: [String], enum: StringEnum, required: false }
    }
  );

  type StringEnumExample = InferSchemaType<typeof stringEnumSchema>;
  ExpectAssignable<StringEnum[] | null | undefined>()({} as StringEnumExample['active']);
  type RawStringEnumExample = InferRawDocType<typeof schemaDefinition>;
  ExpectAssignable<StringEnum[] | null | undefined>()({} as RawStringEnumExample['active']);
  type HydratedStringEnumExample = InferHydratedDocType<typeof schemaDefinition>;
  ExpectAssignable<StringEnum[] | null | undefined>()({} as HydratedStringEnumExample['active']);

  const schemaDefinitionRequired = {
    active: { type: [String], enum: StringEnum, required: true }
  } as const;
  const stringEnumSchemaRequired = new Schema(
    {
      active: { type: [String], enum: StringEnum, required: true }
    }
  );

  type StringEnumRequiredExample = InferSchemaType<typeof stringEnumSchemaRequired>;
  ExpectAssignable<StringEnum[]>()({} as StringEnumRequiredExample['active']);
  type RawStringEnumRequiredExample = InferRawDocType<typeof schemaDefinitionRequired>;
  ExpectAssignable<StringEnum[] | null | undefined>()({} as RawStringEnumRequiredExample['active']);
}

function gh12882() {
  // Array of strings
  const arrString = new Schema({
    fooArray: {
      type: [{
        type: String,
        required: true
      }],
      required: true
    }
  });
  type tArrString = InferSchemaType<typeof arrString>;
  // Array of numbers using string definition
  const arrNum = new Schema({
    fooArray: {
      type: [{
        type: 'Number',
        required: true
      }],
      required: true
    }
  });
  type tArrNum = InferSchemaType<typeof arrNum>;
  ExpectType<{ fooArray: number[] }>({} as tArrNum);
  // Array of object with key named "type"
  const arrType = new Schema({
    fooArray: {
      type: [{
        type: {
          type: String,
          required: true
        },
        foo: {
          type: Number,
          required: true
        }
      }],
      required: true
    }
  });
  type tArrType = InferSchemaType<typeof arrType>;
  type tArrExpectedType = {
    fooArray: Types.DocumentArray<{
      type: string;
      foo: number;
    }>
  };
  ExpectType<tArrExpectedType>({} as tArrType);
  // Readonly array of strings
  const rArrString = new Schema({
    fooArray: {
      type: [{
        type: String,
        required: true
      }] as const,
      required: true
    }
  });
  type rTArrString = InferSchemaType<typeof rArrString>;
  ExpectType<{ fooArray: string[] }>({} as rTArrString);
  // Readonly array of numbers using string definition
  const rArrNum = new Schema({
    fooArray: {
      type: [{
        type: 'Number',
        required: true
      }] as const,
      required: true
    }
  });
  type rTArrNum = InferSchemaType<typeof rArrNum>;
  ExpectType<{ fooArray: number[] }>({} as rTArrNum);
  // Readonly array of object with key named "type"
  const rArrType = new Schema({
    fooArray: {
      type: [{
        type: {
          type: String,
          required: true
        },
        foo: {
          type: Number,
          required: true
        }
      }] as const,
      required: true
    }
  });
  type rTArrType = InferSchemaType<typeof rArrType>;
  type ExpectedType = {
    fooArray: Types.DocumentArray<{
      type: string;
      foo: number;
    }>
  };
  ExpectType<ExpectedType>({} as rTArrType);
}

function gh13534() {
  const schema = new Schema({
    myId: { type: Schema.ObjectId, required: true }
  });
  const Test = model('Test', schema);

  const doc = new Test({ myId: '0'.repeat(24) });
  ExpectType<Types.ObjectId>(doc.myId);
}

function maps() {
  const schema = new Schema({
    myMap: { type: Schema.Types.Map, of: Number, required: true }
  });
  const Test = model('Test', schema);

  const doc = new Test({ myMap: { answer: 42 } });
  ExpectType<Map<string, number>>(doc.myMap);
  ExpectType<number | undefined>(doc.myMap!.get('answer'));
}

function gh13514() {
  const schema = new Schema({
    email: {
      type: String,
      required: {
        isRequired: true,
        message: 'Email is required'
      } as const
    }
  });
  const Test = model('Test', schema);

  const doc = new Test({ email: 'bar' });
  const str: string = doc.email;
}

function gh13633() {
  const schema = new Schema({ name: String });

  schema.pre('updateOne', { document: true, query: false }, function(next) {
  });

  schema.pre('updateOne', { document: true, query: false }, function(doc, update, options) {
    ExpectType<Record<string, any> | undefined>(update);
    ExpectType<Record<string, any> | undefined>(options);
  });

  schema.post('save', function(res, next) {
  });
  schema.pre('insertMany', function(docs) {
  });
  schema.pre('insertMany', function(docs, options) {
    ExpectType<(InsertManyOptions & { lean?: boolean }) | undefined>(options);
  });
}

function gh13702() {
  const schema = new Schema({ name: String });
  ExpectType<[IndexDefinition, IndexOptions][]>(schema.indexes());
}

function gh13780() {
  const schema = new Schema({ num: Schema.Types.BigInt });
  type InferredType = InferSchemaType<typeof schema>;
  ExpectType<bigint | undefined | null>(null as unknown as InferredType['num']);
}

function gh13800() {
  interface IUser {
    firstName: string;
    lastName: string;
    someOtherField: string;
  }
  interface IUserMethods {
    fullName(): string;
  }
  type UserModel = Model<IUser, {}, IUserMethods>;

  // Typed Schema
  const schema = new Schema<IUser, UserModel, IUserMethods>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true }
  });
  schema.method('fullName', function fullName() {
    ExpectType<string>(this.firstName);
    ExpectType<string>(this.lastName);
    ExpectType<string>(this.someOtherField);
    ExpectType<IUserMethods['fullName']>(this.fullName);
  });

  // Auto Typed Schema
  const autoTypedSchema = new Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true }
  });
  autoTypedSchema.method('fullName', function fullName() {
    ExpectType<string>(this.firstName);
    ExpectType<string>(this.lastName);
    // @ts-expect-error  Property 'someOtherField' does not exist on type
    this.someOtherField;
  });
}

async function gh13797() {
  interface IUser {
    name: string;
  }
  new Schema<IUser>({
    name: {
      type: String,
      required: function() {
        ExpectAssignable<HydratedDocument<IUser>>()(this);
        return true;
      }
    }
  });
  new Schema<IUser>({
    name: {
      type: String,
      default: function() {
        ExpectAssignable<HydratedDocument<IUser>>()(this);
        return '';
      }
    }
  });
}

declare const brand: unique symbol;
function gh14002() {
  type Brand<T, U extends string> = T & { [brand]: U };
  type UserId = Brand<string, 'UserId'>;

  interface IUser {
    userId: UserId;
  }

  const userIdTypeHint = 'placeholder' as UserId;
  const schema = new Schema({
    userId: { type: String, required: true, __typehint: userIdTypeHint }
  });
  ExpectType<IUser>({} as InferSchemaType<typeof schema>);
}

function gh14028_methods() {
  // Methods that have access to `this` should have access to typing of other methods on the schema
  interface IUser {
    firstName: string;
    lastName: string;
    age: number;
  }
  interface IUserMethods {
    fullName(): string;
    isAdult(): boolean;
  }
  type UserModel = Model<IUser, {}, IUserMethods>;

  // Define methods on schema
  const schema = new Schema<IUser, UserModel, IUserMethods>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    age: { type: Number, required: true }
  }, {
    methods: {
      fullName() {
        // Expect type of `this` to have fullName method
        ExpectType<IUserMethods['fullName']>(this.fullName);
        return this.firstName + ' ' + this.lastName;
      },
      isAdult() {
        // Expect type of `this` to have isAdult method
        ExpectType<IUserMethods['isAdult']>(this.isAdult);
        return this.age >= 18;
      }
    }
  });

  const User = model('User', schema);
  const user = new User({ firstName: 'John', lastName: 'Doe', age: 20 });
  // Trigger type assertions inside methods
  user.fullName();
  user.isAdult();

  // Expect type of methods to be inferred if accessed directly
  ExpectType<IUserMethods['fullName']>(schema.methods.fullName);
  ExpectType<IUserMethods['isAdult']>(schema.methods.isAdult);

  // Define methods outside of schema
  const schema2 = new Schema<IUser, UserModel, IUserMethods>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    age: { type: Number, required: true }
  });

  schema2.methods.fullName = function fullName() {
    ExpectType<IUserMethods['fullName']>(this.fullName);
    return this.firstName + ' ' + this.lastName;
  };

  schema2.methods.isAdult = function isAdult() {
    ExpectType<IUserMethods['isAdult']>(this.isAdult);
    return true;
  };

  const User2 = model('User2', schema2);
  const user2 = new User2({ firstName: 'John', lastName: 'Doe', age: 20 });
  user2.fullName();
  user2.isAdult();

  type UserModelWithoutMethods = Model<IUser>;
  // Skip InstanceMethods
  const schema3 = new Schema<IUser, UserModelWithoutMethods>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    age: { type: Number, required: true }
  }, {
    methods: {
      fullName() {
        // Expect methods to still have access to `this` type
        ExpectType<string>(this.firstName);
        // @ts-expect-error  Property 'fullName' does not exist on type
        this.fullName;
        return this.firstName + ' ' + this.lastName;
      }
    }
  });

  const User3 = model('User2', schema3);
  const user3 = new User3({ firstName: 'John', lastName: 'Doe', age: 20 });
  // @ts-expect-error  Property 'fullName' does not exist on type
  user3.fullName();
}

function gh14028_statics() {
  // Methods that have access to `this` should have access to typing of other methods on the schema
  interface IUser {
    firstName: string;
    lastName: string;
    age: number;
  }
  interface IUserStatics {
    createWithFullName(name: string): Promise<IUser>;
  }
  type UserModel = Model<IUser, {}>;

  // Define statics on schema
  const schema = new Schema<IUser, UserModel, {}, {}, {}, IUserStatics>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    age: { type: Number, required: true }
  }, {
    statics: {
      createWithFullName(name: string) {
        ExpectType<IUserStatics['createWithFullName']>(schema.statics.createWithFullName);
        ExpectType<UserModel['create']>(this.create);

        const [firstName, lastName] = name.split(' ');
        return this.create({ firstName, lastName });
      }
    }
  });

  // Trigger type assertions inside statics
  schema.statics.createWithFullName('John Doe');
}

function gh13424() {
  const subDoc = {
    name: { type: String, required: true },
    controls: { type: String, required: true }
  };

  const testSchema = {
    question: { type: String, required: true },
    subDocArray: { type: [subDoc], required: true }
  };

  const TestModel = model('TestModel', new Schema(testSchema));

  const doc = new TestModel({});
  ExpectType<Types.ObjectId>(doc.subDocArray[0]._id);
}

function gh14147() {
  const affiliateSchema = new Schema({
    balance: { type: BigInt, default: BigInt(0) }
  });

  const AffiliateModel = model('Affiliate', affiliateSchema);

  const doc = new AffiliateModel();
  ExpectType<bigint>(doc.balance);
}

function gh14235() {
  interface IUser {
    name: string;
    age: number;
  }

  const userSchema = new Schema<IUser>({ name: String, age: Number });

  userSchema.omit<Omit<IUser, 'age'>>(['age']);
}

function gh14496() {
  const schema = new Schema({
    name: {
      type: String
    }
  });
  schema.path('name').validate({
    validator: () => {
      throw new Error('Oops!');
    },
    // `errors['name']` will be "Oops!"
    message: (props) => {
      ExpectType<Error | undefined>(props.reason);
      return 'test';
    }
  });
}

function gh14367() {
  const UserSchema = new Schema({
    counts: [Schema.Types.Number],
    roles: [Schema.Types.String],
    dates: [Schema.Types.Date],
    flags: [Schema.Types.Boolean]
  });

  type IUser = InferSchemaType<typeof UserSchema>;

  const x: IUser = {
    counts: [12],
    roles: ['test'],
    dates: [new Date('2016-06-01')],
    flags: [true]
  };
}

function gh14573() {
  interface Names {
    _id: Types.ObjectId;
    firstName: string;
  }

  // Document definition
  interface User {
    names: Names;
  }

  // Define property overrides for hydrated documents
  type THydratedUserDocument = {
    names?: HydratedSingleSubdocument<Names>;
  };

  type UserMethods = {
    getName(): Names | undefined;
  };

  type UserModelType = Model<User, {}, UserMethods, {}, THydratedUserDocument>;

  const userSchema = new Schema<
    User,
    UserModelType,
    UserMethods,
    {},
    {},
    {},
    DefaultSchemaOptions,
    User,
    THydratedUserDocument
  >(
    {
      names: new Schema<Names>({ firstName: String })
    },
    {
      methods: {
        getName() {
          const str: string | undefined = this.names?.firstName;
          return this.names?.toObject();
        }
      }
    }
  );
  const UserModel = model<User, UserModelType>('User', userSchema);
  const doc = new UserModel({ names: { _id: '0'.repeat(24), firstName: 'foo' } });
  doc.names?.ownerDocument();
}

function gh13772() {
  const schemaDefinition = {
    name: String,
    docArr: [{ name: String }]
  } as const;
  const schema = new Schema(schemaDefinition);

  const TestModel = model('User', schema);
  type RawDocType = InferRawDocType<typeof schemaDefinition>;
  ExpectAssignable<
    { name?: string | null, docArr?: Array<{ name?: string | null }> | null }
  >()({} as RawDocType);

  const doc = new TestModel();
  ExpectAssignable<RawDocType>()(doc.toObject());
  ExpectAssignable<RawDocType>()(doc.toJSON());
}

function gh14696() {
  interface User {
    name: string;
    isActive: boolean;
    isActiveAsync: boolean;
  }

  const x: ValidateOpts<unknown, User> = {
    validator(v: any) {
      ExpectAssignable<User | Query<unknown, User>>()(this);
      return !v || this instanceof Query || this.name === 'super admin';
    }
  };

  interface IUserMethods {
    isSuperAdmin(): boolean;
  }

  type UserModelType = Model<User, {}, IUserMethods>;
  const userSchema = new Schema<User, UserModelType, IUserMethods>({
    name: {
      type: String,
      required: [true, 'Name on card is required']
    },
    isActive: {
      type: Boolean,
      default: false,
      validate: {
        validator(v: any) {
          ExpectAssignable<User | Query<unknown, User>>()(this);
          if (!v) {
            return true;
          }
          return this.get('name') === 'super admin' || (!(this instanceof Query) && this.isSuperAdmin());
        }
      }
    },
    isActiveAsync: {
      type: Boolean,
      default: false,
      validate: {
        async validator(v: any) {
          ExpectAssignable<User | Query<unknown, User>>()(this);
          if (this instanceof Query) {
            const doc = await this.clone().findOne().orFail();
            return doc.isSuperAdmin();
          }
          return !v || this.get('name') === 'super admin';
        }
      }
    }
  });

}

function gh14748() {
  const nestedSchema = new Schema({ name: String });

  const schema = new Schema({
    arr: [nestedSchema],
    singleNested: nestedSchema
  });

  const subdoc = schema.path('singleNested')
    .cast<HydratedArraySubdocument<{ name: string }>>({ name: 'bar' });
  ExpectAssignable<{ name: string }>()(subdoc);

  const subdoc2 = schema.path('singleNested').cast({ name: 'bar' });
  ExpectAssignable<{ name: string }>()(subdoc2);

  const subdoc3 = schema.path<Schema.Types.Subdocument<{ name: string }>>('singleNested').cast({ name: 'bar' });
  ExpectAssignable<{ name: string }>()(subdoc3);
}

function gh13215() {
  const schemaDefinition = {
    userName: { type: String, required: true }
  } as const;
  const schemaOptions = {
    typeKey: 'type',
    timestamps: {
      createdAt: 'date',
      updatedAt: false
    }
  } as const;

  type RawDocType = InferRawDocType<
    typeof schemaDefinition,
    typeof schemaOptions
  >;
  type User = {
    userName: string;
    date: Date;
  };

  ExpectType<User & { _id: Types.ObjectId }>({} as RawDocType);

  const schema = new Schema(schemaDefinition, schemaOptions);
  type SchemaType = InferSchemaType<typeof schema>;
  ExpectType<User>({} as SchemaType);
}

function gh14825() {
  const schemaDefinition = {
    userName: { type: String, required: true }
  } as const;
  const schemaOptions = {
    typeKey: 'type' as const,
    timestamps: {
      createdAt: 'date',
      updatedAt: false
    }
  };

  type RawDocType = InferRawDocType<
    typeof schemaDefinition,
    typeof schemaOptions
  >;
  type User = {
    userName: string;
  };

  ExpectAssignable<User>()({} as RawDocType);

  const schema = new Schema(schemaDefinition, schemaOptions);
  type SchemaType = InferSchemaType<typeof schema>;
  ExpectAssignable<User>()({} as SchemaType);
}

function gh8389() {
  const schema = new Schema({ name: String, tags: [String] });

  ExpectAssignable<SchemaType<any> | undefined>()(schema.path('name').getEmbeddedSchemaType());
  ExpectAssignable<SchemaType<any> | undefined>()(schema.path('tags').getEmbeddedSchemaType());
}

function gh14879() {
  Schema.Types.String.setters.push((val?: unknown) => typeof val === 'string' ? val.trim() : val);
}

async function gh14950() {
  const SightingSchema = new Schema(
    {
      _id: { type: Schema.Types.ObjectId, required: true },
      location: {
        type: { type: String, required: true },
        coordinates: [{ type: Number }]
      }
    }
  );

  const TestModel = model('Test', SightingSchema);
  const doc = await TestModel.findOne().orFail();

  ExpectType<string>(doc.location!.type);
  ExpectType<number[]>(doc.location!.coordinates);
}

async function gh14902() {
  const exampleSchema = new Schema({
    image: { type: Buffer },
    subdoc: {
      type: new Schema({
        testBuf: Buffer
      })
    }
  });
  const Test = model('Test', exampleSchema);

  const doc = await Test.findOne().lean().orFail();
  ExpectType<Binary | null | undefined>(doc.image);
  ExpectType<Binary | null | undefined>(doc.subdoc!.testBuf);
}

async function gh14451() {
  const exampleSchema = new Schema({
    myId: { type: 'ObjectId' },
    myRequiredId: { type: 'ObjectId', required: true },
    myBuf: { type: Buffer, required: true },
    subdoc: {
      type: new Schema({
        subdocProp: Date
      })
    },
    docArr: [{ nums: [Number], times: [{ type: Date }] }],
    myMap: {
      type: Map,
      of: String
    },
    myUUID: 'UUID'
  });

  const Test = model('Test', exampleSchema);

  type TestJSON = JSONSerialized<InferSchemaType<typeof exampleSchema>>;
  ExpectType<{
    myId?: string | undefined | null,
    myRequiredId: string,
    myBuf: { type: 'buffer', data: number[] },
    subdoc?: {
      subdocProp?: string | undefined | null
    } | null,
    docArr: { nums: number[], times: string[] }[],
    myMap?: Record<string, string> | null | undefined,
    myUUID?: string | null | undefined
  }>({} as TestJSON);
}

async function gh12959() {
  const schema = new Schema({ name: String });
  const TestModel = model('Test', schema);

  const doc = await TestModel.findOne().orFail();
  ExpectType<number>(doc.__v);
  const leanDoc = await TestModel.findOne().lean().orFail();
  ExpectType<number>(leanDoc.__v);
}

async function gh15236() {
  const schema = new Schema({
    myNum: { type: Number }
  });

  schema.path<Schema.Types.Number>('myNum').min(0);
}

function gh15244() {
  const schema = new Schema({});
  schema.discriminator('Name', new Schema({}), { value: 'value' });
}

async function schemaDouble() {
  const schema = new Schema({ balance: 'Double' });
  const TestModel = model('Test', schema);

  const doc = await TestModel.findOne().orFail();
  ExpectType<Types.Double | null | undefined>(doc.balance);
}

function gh15301() {
  interface IUser {
    time: { hours: number, minutes: number }
  }
  const userSchema = new Schema<IUser>({
    time: {
      type: new Schema(
        {
          hours: { type: Number, required: true },
          minutes: { type: Number, required: true }
        },
        { _id: false }
      ),
      required: true
    }
  });

  const timeStringToObject = (time: string) => {
    const [hours, minutes] = time.split(':');
    return { hours: parseInt(hours), minutes: parseInt(minutes) };
  };

  userSchema.pre('init', function(rawDoc) {
    ExpectType<IUser>(rawDoc);
    if (typeof rawDoc.time === 'string') {
      rawDoc.time = timeStringToObject(rawDoc.time);
    }
  });
}

function gh15412() {
  const ScheduleEntrySchema = new Schema({
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: false }
  });
  const ScheduleEntry = model('ScheduleEntry', ScheduleEntrySchema);

  type ScheduleEntryDoc = ReturnType<typeof ScheduleEntry['hydrate']>

  ScheduleEntrySchema.post('init', function(this: ScheduleEntryDoc, _res: any, next: CallbackWithoutResultAndOptionalError) {
    ExpectType<Date>(this.startDate);
    ExpectType<Date | null | undefined>(this.endDate);
    next();
  });
}

function defaultReturnsUndefined() {
  const schema = new Schema<{ arr: number[] }>({
    arr: {
      type: [Number],
      default: () => void 0
    }
  });
}

function gh15479() {
  const TestSchema = new Schema({
    name: String,
    testField: {
      type: String,
      required: true,
      default: 'blah'
    }
  });

  function transform(doc: unknown, ret: InferSchemaType<typeof TestSchema>) {
    const { testField, ...val } = ret;
    return val;
  }

  TestSchema.set('toJSON', { transform });

  const TestModel = model('Test', TestSchema);

  const doc = new TestModel();

  getTestField(doc.toJSON<ReturnType<typeof transform> & { testField: string }>());
  // @ts-expect-error  Property 'testField' is missing in type '{ name?: string | null | undefined; } & { _id: ObjectId; } & { __v: number; }'
  getTestField(doc.toJSON<ReturnType<typeof transform>>());

  function getTestField(obj: { testField: string }) {
    return obj.testField;
  }
}

function gh15494() {
  const SchemaA = new Schema({ name: String });
  const SchemaB = new Schema({ name: String }, { versionKey: false });

  const ModelA = model('ModelA', SchemaA);
  const ModelB = model('ModelB', SchemaB);

  type HydratedA = ReturnType<(typeof ModelA)['hydrate']>;
  type HydratedB = ReturnType<(typeof ModelB)['hydrate']>;

  const docA = new ModelA({ name: 'Alice' });
  const docB = new ModelB({ name: 'Bob' });

  // Should have __v
  ExpectType<number>(docA.__v);
  // @ts-expect-error  Property '__v' does not exist on type
  docB.__v;

  const objA = docA.toObject();
  ExpectType<number>(objA.__v);

  const objB = docB.toObject();
  // @ts-expect-error  Property '__v' does not exist on type
  objB.__v;
}

function gh15516() {
  interface IUser {
    name: string;
  }
  type HydratedUserDoc = HydratedDocument<IUser & { customProperty: number, myVirtual: number }>;
  const schema = new Schema<IUser, Model<IUser>, {}, {}, { myVirtual: number }, {}, DefaultSchemaOptions, any, HydratedUserDoc>({
    name: String
  });

  schema.virtual('myVirtual').get(function() {
    ExpectType<HydratedUserDoc>(this);
  });
}

function testInferRawDocTypeFromSchema() {
  const schema = new Schema({
    name: String,
    arr: [Number],
    docArr: [{ name: { type: String, required: true } }],
    subdoc: new Schema({
      answer: { type: Number, required: true }
    }),
    map: { type: Map, of: String }
  });

  type RawDocType = InferRawDocTypeFromSchema<typeof schema>;

  ExpectType<{
    name?: string | null | undefined,
    arr: number[],
    docArr: { name: string }[],
    subdoc?: { answer: number } | null | undefined,
    map?: Record<string, string> | null | undefined
  }>({} as RawDocType);
}

function testInferHydratedDocTypeFromSchema() {
  const schema = new Schema({
    name: String,
    arr: [Number],
    docArr: [{ name: { type: String, required: true } }],
    subdoc: new Schema({ answer: { type: Number, required: true } }),
    map: { type: Map, of: String }
  });

  type HydratedDocType = InferHydratedDocTypeFromSchema<typeof schema>;

  type Expected = HydratedDocument<{
    name?: string | null | undefined,
    arr: number[],
    docArr: Types.DocumentArray<{ name: string }>,
    subdoc?: { answer: number } | null | undefined,
    map?: Map<string, string> | null | undefined
  }, { id: string }, {}, { id: string }>;

  ExpectType<Expected>({} as HydratedDocType);
}

function gh15536() {
  const UserModelNameRequiredCustom = model('User', new Schema(
    {
      name: { type: String, required: 'This is a custom error message' }
    }
  ));

  const user3 = new UserModelNameRequiredCustom({ name: null });
  ExpectType<string>(user3.name);
}

function gh10894() {
  function autoInferred() {
    const schema = new Schema({
      testProp: {
        type: 'Union',
        of: [String, Number]
      }
    });
    const TestModel = model('Test', schema);

    type InferredDocType = InferSchemaType<typeof schema>;
    ExpectType<string | number | null | undefined>({} as InferredDocType['testProp']);

    const doc = new TestModel({ testProp: 42 });
    ExpectType<string | number | null | undefined>(doc.testProp);

    const toObject = doc.toObject();
    ExpectType<string | number | null | undefined>(toObject.testProp);

    const schemaDefinition = {
      testProp: {
        type: 'Union',
        of: ['String', 'Number']
      }
    } as const;
    type RawDocType = InferRawDocType<typeof schemaDefinition>;
    ExpectType<string | number | null | undefined>({} as RawDocType['testProp']);
  }
}

function autoInferredNestedMaps() {
  const schema = new Schema({
    nestedMap: {
      type: Map,
      required: true,
      of: {
        type: Map,
        of: String
      }
    }
  });
  const TestModel = model('Test', schema);
  const doc = new TestModel({ nestedMap: new Map([['1', new Map([['2', 'value']])]]) });
  ExpectType<Map<string, Map<string, string>>>(doc.nestedMap);
}

function gh15751() {
  const schema = new Schema({
    myId: {
      type: Types.ObjectId,
      required: true
    }
  });
  const TestModel = model('Test', schema);
  const doc = new TestModel();
  ExpectType<Types.ObjectId>(doc.myId);
}

function testNewSchemaWithMethodsAndVirtuals() {
  const schema = new Schema(
    { name: String },
    {
      virtuals: {
        upperName: {
          get(): string | undefined {
            return this.name?.toUpperCase();
          }
        }
      },
      methods: {
        greet(greeting: string) {
          return `${greeting}, ${this.name}`;
        }
      }
    }
  );

  const TestModel = model('Test', schema);
  const doc = new TestModel({ name: 'test' });

  const greeting = doc.greet('Hello');
  ExpectType<string>(greeting);

  ExpectType<string | undefined>(doc.upperName);
}

function gh15878() {
  const schema = new Schema({
    name: {
      type: String,
      default: null
    },
    age: {
      type: Number,
      default: () => null
    }
  });
  const TestModel = model('Test', schema);
  const doc = new TestModel({ name: 'John', age: 30 });
  ExpectType<string | null | undefined>(doc.name);
  ExpectType<number | null | undefined>(doc.age);
}

function gh15915() {
  type OptimisticConcurrencyType = SchemaOptions['optimisticConcurrency'];
  ExpectType<boolean | string[] | { exclude: string[] } | undefined>({} as OptimisticConcurrencyType);

  // optimisticConcurrency: boolean
  new Schema({ name: String }, { optimisticConcurrency: true });
  new Schema({ name: String }, { optimisticConcurrency: false });

  // optimisticConcurrency: string[]
  new Schema({ name: String, balance: Number }, { optimisticConcurrency: ['balance'] });
  new Schema({ name: String, balance: Number }, { optimisticConcurrency: ['name', 'balance'] });

  // optimisticConcurrency: { exclude: string[] }
  new Schema({ name: String, balance: Number }, { optimisticConcurrency: { exclude: ['name'] } });
  new Schema({ name: String, balance: Number }, { optimisticConcurrency: { exclude: ['name', 'balance'] } });

  // invalid types
  new Schema({ name: String }, {
    // @ts-expect-error  Type 'string' is not assignable to type 'boolean | string[] | { exclude: string[]; } | undefined'.
    optimisticConcurrency: 'invalid'
  });
  new Schema({ name: String }, { optimisticConcurrency: {
    // @ts-expect-error  'invalid' does not exist in type 'string[] | { exclude: string[]; }'.
    invalid: ['name'] }
  });
}

function gh16046() {
  const issueOneSchema = new Schema(
    { placeholder: String },
    {
      timestamps: true,
      virtuals: {
        votes: {
          options: {
            ref: 'IssueTwo',
            localField: '_id',
            foreignField: 'issueOneId'
          }
        }
      },
      statics: {
        myStaticMethod: function() {
          ExpectType<string>(this.modelName);
        }
      }
    }
  );

  const IssueOne = model('IssueOne', issueOneSchema);

  IssueOne.myStaticMethod();

  const issueTwoSchema = new Schema(
    { placeholder: String },
    {
      timestamps: true,
      virtuals: {
        votes: {
          options: {
            ref: 'IssueTwo',
            localField: '_id',
            foreignField: 'issueOneId'
          }
        }
      },
      methods: {
        myMethod: function() {
          ExpectType<string | null | undefined>(this.placeholder);
        }
      },
      statics: {
        myStaticMethod: function() {
          ExpectType<string>(this.modelName);
          console.log('placeholder', this.modelName);
        }
      }
    }
  );

  const IssueTwo = model('IssueTwo', issueTwoSchema);
  (new IssueTwo()).myMethod();
  IssueTwo.myStaticMethod();
}

function gh16046VersionKeyFalse() {
  const mySchema = new Schema(
    { name: { type: String, required: true } },
    {
      versionKey: false,
      statics: {
        testMe: function() {
          ExpectType<string>(this.modelName);
        }
      }
    }
  );

  const MyModel = model('Test', mySchema);

  MyModel.testMe();
}

function gh16045() {
  const circleSchema = new Schema({
    kind: { type: String, enum: ['Circle'] },
    name: {
      baseName: String
    },
    radius: Number
  });
  const squareSchema = new Schema({
    kind: { type: String, enum: ['Square'] },
    side: Number
  });

  const shapeSchema = new Schema({ name: String }, { discriminatorKey: 'kind' });
  const schema = new Schema({
    shape: {
      type: shapeSchema,
      discriminators: {
        Circle: circleSchema,
        Square: squareSchema
      }
    }
  });

  type ShapeDocType = InferSchemaType<typeof schema>['shape'];
  ExpectType<
    |(Omit<InferSchemaType<typeof shapeSchema>, keyof InferSchemaType<typeof circleSchema>> & InferSchemaType<typeof circleSchema>)
      | (Omit<InferSchemaType<typeof shapeSchema>, keyof InferSchemaType<typeof squareSchema>> & InferSchemaType<typeof squareSchema>)
      | null
      | undefined
      >({} as ShapeDocType);
  ExpectType<
    | string
    | { baseName?: string | null | undefined }
    | null
    | undefined
  >({} as NonNullable<ShapeDocType>['name']);

  const Model = model('EmbeddedDiscriminatorPathOption', schema);
  const circleDoc = new Model({ shape: { kind: 'Circle', radius: 5 } });
  const squareDoc = new Model({ shape: { kind: 'Square', side: 10 } });

  for (const doc of [circleDoc, squareDoc]) {
    if (doc.shape?.kind === 'Circle') {
      ExpectType<number | null | undefined>(doc.shape.radius);
      ExpectType<{ baseName?: string | null | undefined } | null | undefined>(doc.shape.name);
      ExpectType<string | null | undefined>(doc.shape.name?.baseName);
      // @ts-expect-error Property 'side' does not exist on type
      doc.shape.side;
    }

    if (doc.shape?.kind === 'Square') {
      ExpectType<number | null | undefined>(doc.shape.side);
      ExpectType<string | null | undefined>(doc.shape.name);
      // @ts-expect-error Property 'radius' does not exist on type
      doc.shape.radius;
    }
  }
}

function gh16045DocumentArray() {
  const circleSchema = new Schema({
    kind: { type: String, enum: ['Circle'] },
    name: {
      baseName: String
    },
    radius: Number
  });
  const squareSchema = new Schema({
    kind: { type: String, enum: ['Square'] },
    side: Number
  });

  const shapeSchema = new Schema({ name: String }, { discriminatorKey: 'kind' });
  const schema = new Schema({
    shapes: [{
      type: shapeSchema,
      discriminators: {
        Circle: circleSchema,
        Square: squareSchema
      }
    }]
  });

  type ShapeElementType = NonNullable<InferSchemaType<typeof schema>['shapes']>[number];
  ExpectType<
    |(Omit<InferSchemaType<typeof shapeSchema>, keyof InferSchemaType<typeof circleSchema>> & InferSchemaType<typeof circleSchema>)
      | (Omit<InferSchemaType<typeof shapeSchema>, keyof InferSchemaType<typeof squareSchema>> & InferSchemaType<typeof squareSchema>)
      >({} as ShapeElementType);

  const Model = model('EmbeddedDiscriminatorPathOptionDocArray', schema);
  const circleDoc = new Model({ shapes: [{ kind: 'Circle', radius: 5, name: { baseName: 'a' } }] });
  const squareDoc = new Model({ shapes: [{ kind: 'Square', side: 10, name: 'b' }] });

  for (const doc of [circleDoc, squareDoc]) {
    for (const shape of doc.shapes!) {
      if (shape.kind === 'Circle') {
        ExpectType<number | null | undefined>(shape.radius);
        ExpectType<{ baseName?: string | null | undefined } | null | undefined>(shape.name);
        // @ts-expect-error Property 'side' does not exist on type
        shape.side;
      }

      if (shape.kind === 'Square') {
        ExpectType<number | null | undefined>(shape.side);
        ExpectType<string | null | undefined>(shape.name);
        // @ts-expect-error Property 'radius' does not exist on type
        shape.radius;
      }
    }
  }
}

function allowNullFalseInferredTypes() {
  const schema = new Schema({
    name: { type: String, allowNull: false },
    age: Number,
    status: String,
    endDate: {
      type: Date,
      required: function() { return this.status === 'completed'; },
      allowNull: false
    }
  });

  type InferredDocType = InferSchemaType<typeof schema>;
  ExpectType<{ name?: string, age?: number | null, status?: string | null, endDate?: Date }>({} as InferredDocType);
  ExpectType<string | undefined>({} as InferredDocType['name']);
  ExpectType<Date | undefined>({} as InferredDocType['endDate']);
  ExpectType<number | null | undefined>({} as InferredDocType['age']);
  // @ts-expect-error Argument of type 'null' is not assignable to parameter of type 'string | undefined'.
  ExpectType<InferredDocType['name']>(null);
  // @ts-expect-error Argument of type 'null' is not assignable to parameter of type 'NativeDate | undefined'.
  ExpectType<InferredDocType['endDate']>(null);

  const defaultSchema = new Schema({
    title: String
  });
  type DefaultInferredDocType = InferSchemaType<typeof defaultSchema>;
  ExpectType<string | null | undefined>({} as DefaultInferredDocType['title']);

  const schemaDefinition = {
    name: { type: String, allowNull: false },
    title: String
  } as const;
  type RawDocType = InferRawDocType<typeof schemaDefinition>;
  ExpectType<string | undefined>({} as RawDocType['name']);
  ExpectType<string | null | undefined>({} as RawDocType['title']);
  // @ts-expect-error Argument of type 'null' is not assignable to parameter of type 'string | undefined'.
  ExpectType<RawDocType['name']>(null);
}
